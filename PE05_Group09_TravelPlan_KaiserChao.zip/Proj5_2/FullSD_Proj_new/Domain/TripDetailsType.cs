﻿ namespace FullSD_Proj_new.Domain
{
    public class TripDetailsType : BaseDomainModel
    {
        public string? Note { get; set; }
        public string? Activity { get; set; }
        public string? Accomodation { get; set; }
        public string? Transport { get; set; }

    }
}
