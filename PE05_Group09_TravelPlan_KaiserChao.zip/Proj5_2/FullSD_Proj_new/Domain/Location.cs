﻿namespace FullSD_Proj_new.Domain
{
    public class Location : BaseDomainModel
    {
        public string? Name { get; set; }
        public string? Type { get; set; }
    }
}
